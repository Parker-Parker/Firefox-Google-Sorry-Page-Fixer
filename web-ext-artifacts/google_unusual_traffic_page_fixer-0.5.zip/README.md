# Firefox-Google-Sorry-Page-Fixer
Small addon to fix google.com/sorry pages

